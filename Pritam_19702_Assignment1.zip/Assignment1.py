import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy import optimize

#Read
#data = pd.read_csv("/content/drive/MyDrive/Data/04_cricket_1999to2011.csv")
data = pd.read_csv("../Data/04_cricket_1999to2011.csv")

#Preprocess
data = data[data["Innings"] == 1]
data = data.groupby(by = ['Match']).filter(lambda g: g['Wickets.in.Hand'].min()==0 or g['Over'].count()==50)
data['Total.Runs'] = data.groupby('Match')['Runs'].cumsum()
data['Innings.Total.Runs'] = data.groupby('Match')['Total.Runs'].transform('max')
data['Runs.Remaining'] = data['Innings.Total.Runs'] - data['Total.Runs']
data['Overs.Remaining'] = 50 - data['Over']

w_in_h = data.groupby('Wickets.in.Hand')

Z0 = []
for i in range(1,11):
  d = data[data['Wickets.in.Hand'] == i]
  max_runs = d.groupby('Match')['Runs.Remaining'].max()
  Z0.append(np.mean(max_runs))

def model(Z0,L,u):
  val = Z0*(1-np.exp(-L*u/Z0))
  return val

match = data.groupby('Match')
n_matches = match.first()['Innings.Total.Runs'].to_numpy()

def error(parameters):
  z0 = parameters[0:10]
  L = parameters[10]
  err = 0
  mse = 0
  for i in range(1,11):
    z = model(Z0[i-1], L, w_in_h.get_group(i)['Overs.Remaining'].to_numpy())
    mse += np.sum((z - w_in_h.get_group(i)['Runs.Remaining'].to_numpy())**2)
  
  z = model(Z0[9],L,50)
  mse2 = np.sum((z-n_matches)**2)
  return (mse+mse2)/(length+n_matches.shape[0])

Z0.append(5)
z_opt = optimize.minimize(error, Z0, method='L-BFGS-B')
print('MSE -> ' + str(z_opt.fun))
L_opt = z_opt.x[-1]
Z0_opt = z_opt.x[:-1]

u = np.linspace(0, 50, num=300)
Z_final = []
for i in range(10):
    Z_final.append(model(Z0[i], L_opt, u))

plt.figure()
for i in range(10):
    plt.plot(u, Z_final[i])
plt.title("Runs to be scored")
plt.xlabel('Overs remaining')
plt.ylabel('Average Runs Obtainable')
plt.xlim((0, 50))
plt.xticks([0, 5, 10, 15, 20, 25, 30, 35, 40, 45, 50])
plt.legend(['1', '2', '3', '4', '5', '6', '7', '8', '9', '10'])
plt.grid()
plt.show()